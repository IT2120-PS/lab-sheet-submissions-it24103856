setwd("C:\\Users\\kavun\\Desktop\\IT24103856")

data<-read.table("Data.txt",header = TRUE ,sep = ",")
fix(data)
attach(data)

names(data)<-c("X1","X2")
attach(data)
hist(X2,main="Histogram for number of shareholders")

##part 2

histogram<-hist(X2,main ="Histogram for number of shareholders",breaks = seq(130,270,length=8),right = FALSE )
?hist

##PART 3

breaks<-round(histogram$breaks)
freq<-histogram$counts
mids<-histogram$mids

classes<-c()

for(i in 1:length(breaks)-1){
  classes[i]<-paste0("[",breaks[i],",",breaks[i+1],")")
}

cbind(classes =classes,frequency=freq)

##PART 4

lines(mids,freq)
plot(mids, freq, 
     type = "l", 
     main = "Frequency polygon for shareholders", 
     xlab = "Shareholders", 
     ylab = "Frequency", 
     ylim = c(0, max(freq)))

##part 5
cum.freq <- cumsum(freq)

# Create cumulative frequencies aligned with class boundaries
new <- numeric(length(breaks))   # empty numeric vector
for (i in 1:length(breaks)) {
  if (i == 1) {
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i-1]
  }
}

# Plot cumulative frequency polygon
plot(breaks, new, 
     type = "l",   # line
     main = "Cumulative Frequency Polygon for Shareholders",
     xlab = "Shareholders", 
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))

# Show table of upper boundaries and cumulative frequencies
cbind(upper = breaks, cumFreq = new)


##EXERCISE





setwd("C:\\Users\\kavun\\Desktop\\IT24103856")
##1
DeliveryTimes <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Check the data
head(DeliveryTimes)
str(DeliveryTimes)

##2
DeliveryTimes$DeliveryTime <- as.numeric(as.character(DeliveryTimes$DeliveryTime))
# Set breaks for 9 intervals between 20 and 70
breaks <- seq(20, 70, length.out = 10)

# Draw histogram
hist(DeliveryTimes$Delivery_Time_.minutes.,
     breaks = breaks,
     right = FALSE,  # right-open intervals
     main = "Histogram of Delivery Times",
     xlab = "Delivery Times (minutes)",
     ylab = "Frequency",
     col = "lightblue",
     border = "black")


##part 4
# Compute frequency for each class
freq <- hist(DeliveryTimes$Delivery_Time_.minutes., 
             breaks = breaks, plot = FALSE)$counts

# Compute cumulative frequency
cum.freq <- cumsum(freq)

# Create points for ogive (include 0 at the start)
cum.freq.points <- c(0, cum.freq)
breaks.points <- breaks  # breaks already has one extra for right-open intervals

# Plot ogive
plot(breaks.points, cum.freq.points,
     type = "b",  # points connected with lines
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Times (minutes)",
     ylab = "Cumulative Frequency",
     col = "blue",
     pch = 19)

