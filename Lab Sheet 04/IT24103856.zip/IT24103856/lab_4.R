setwd("C:\\Users\\it24103856\\Desktop\\IT24103856")




data<-read.table("Data 4.txt",header =TRUE,sep="" )
fix(data)
attach(data)

##part  2
##part a
boxplot(X1,main="Boxplot for team attendance",outline =TRUE,outpch=8,horizontal = TRUE )
boxplot(X2,main="Boxplot for team salary",outline =TRUE,outpch=8,horizontal = TRUE )
boxplot(X3,main="Boxplot for year",outline =TRUE,outpch=8,horizontal = TRUE )

##obtain histogram
hist(X1,ylab = "Frequency",xlab = "Team attendance",main ="Histogram for team attendace" )
hist(X2,ylab = "Frequency",xlab = "Team salary",main ="Histogram for team salary" )
hist(X3,ylab = "Frequency",xlab = "Years",main ="Histogram for year" )

#stem & leaf plot
stem(X1)
stem(X2)
stem(X3)

##part b
##Mean 
mean(X1)
mean(X2)
mean(X3)

##medin
median(X1)
median(X2)
median(X3)

##standard 
sd(X1)
sd(X2)
sd(X3)

##part(c)

summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X1)[2]
quantile(X1)[4]

##part (d)

IQR(X1)
IQR(X2)
IQR(X3)

##part 3

get.mode<-function(Y){
  counts<-table(X3)
  names(counts[counts==max(counts)])
}

get.mode(X3)




##part 3
get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = " ")))
}
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)








branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")

##2
str(branch_data)

##3
boxplot(branch_data$Sales_X1, main="Boxplot for Sales", ylab="Sales")

##4

branch_data<-read.table("Exercise.txt",header = TRUE,sep = ",")
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

##5
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- IQR(x)
  lower <- q1 - 1.5 * iqr
  upper <- q3 + 1.5 * iqr
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

# Check outliers in Years_X3
find_outliers(branch_data$Years_X3)
